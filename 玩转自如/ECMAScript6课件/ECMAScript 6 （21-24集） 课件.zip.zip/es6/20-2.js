console.log( a );
a+=1