console.log( "20-3" )
console.log( a );