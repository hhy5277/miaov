
import {c} from "./b.js"
console.log( c )