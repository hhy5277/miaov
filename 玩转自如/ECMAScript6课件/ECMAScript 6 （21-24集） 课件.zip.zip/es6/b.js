var c = 3000;
function addOne(){
	c += 100
}

export {c,addOne}