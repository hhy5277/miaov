console.log( "20-a,加载" );
// var a = 1;

// import {newN,m,add} from "./a.js";
// // console.log( n )

// console.log( add( newN,m ) )


// import {n} from "./a.js"
// console.log( n )

// import f from "./a.js";
// console.log( f )

// var m = 100

// import {newN,m as newM,add} from "./a.js";
// console.log( add( newN,newM ) )

// import * as tool from "./a.js";
// console.log( tool.m,tool.newN,tool.default )

// import num,{ m,add } from "./a.js";
// console.log( num,m,add )

// import "./a.js"

// console.log( this )

import {c,addOne} from "./b.js"
addOne()
console.log( c )
// c = 200