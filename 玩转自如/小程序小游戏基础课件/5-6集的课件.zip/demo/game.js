var canvas = wx.createCanvas()
var ctx = canvas.getContext('2d')

ctx.fillStyle = 'red'

// ctx.clearRect(0, 0, canvas.width, canvas.height)
// ctx.fillRect(0,20, 100, 100)
// ctx.clearRect(0, 0, canvas.width, canvas.height)
// ctx.fillRect(0, 150, 100, 100)

//间隔定时器动画
// var num = 0
// var timer = null
// timer = setInterval(function(){
//   num++
//   ctx.clearRect(0, 0, canvas.width, canvas.height)
//   ctx.fillRect(0, num, 100, 100)

//   if(num>150){
//     clearInterval(timer)
//   }
// },20)

//延迟定时器
// ctx.fillRect(0, 0, 100, 100)
// setTimeout(function(){
//   ctx.clearRect(0, 0, canvas.width, canvas.height)
//   ctx.fillRect(0, 150, 100, 100)
// },1000)

//延迟定时器去做连贯动画
// ctx.fillRect(0, 0, 100, 100)

// var num = 0
// var timer = null
// loop()
// function loop(){
//   num++
//   timer = setTimeout(function () {
//     ctx.clearRect(0, 0, canvas.width, canvas.height)
//     ctx.fillRect(0, num, 100, 100)
//     clearTimeout(timer)
//     if(num<=150){
//       loop()
//     }
//   }, 20)
// }

//requestAnimationFrame制作动画
var num = 0
var timer = null
loop()
function loop(){
  num++
  cancelAnimationFrame(timer)
  timer = requestAnimationFrame(function(){
    ctx.clearRect(0, 0, canvas.width, canvas.height)
    ctx.fillRect(0, num, 100, 100)
    if(num<=150){
      loop()
    } 
  })
}