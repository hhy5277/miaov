// document.createElement('canvas')
// document.createElement('audio')
var document = {
  createElement:function(tagName){
    tagName = tagName.toLowerCase()
    if (tagName==='canvas'){
      return wx.createCanvas()
    }
    else if (tagName === 'audio'){
      return wx.createInnerAudioContext()
    }
  }
}
function Image(){
  return wx.createImage()
}
var img = new Image()
console.log(img)

// window

console.log(GameGlobal.setTimeout == setTimeout)

var window = {
  innerWidth: GameGlobal.innerWidth,
  innerHeight: GameGlobal.innerHeight
}

console.log(window.innerHeight)

//这个插件创建了一个上屏，并且暴露出来的接口叫做canvas
