var canvas = wx.createCanvas()
var ctx = canvas.getContext('2d')

var img = wx.createImage()
img.src = './source/hero.png'

var firstX = 0
var firstY = 0
var imgW = 93
var imgH = 65
var isMove = false

img.onload = function(){
  ctx.drawImage(img, firstX, firstY, imgW, imgH)
}

wx.onTouchStart(function(e){
  
  var touch = e.changedTouches[0]
  var touX = touch.clientX
  var touY = touch.clientY

  if (touX > firstX && touX < firstX + imgW && touY > firstY && touY < firstY + imgH ){
    isMove = true
  }
})

wx.onTouchMove(function(e){
  var touch = e.changedTouches[0]
  if (isMove){
    firstX = touch.clientX - imgW / 2
    firstY = touch.clientY - imgH / 2
    ctx.clearRect(0,0,canvas.width,canvas.height)
    ctx.drawImage(img, firstX,firstY, imgW, imgH)
  }
})

wx.onTouchEnd(function(){
  isMove = false
})


wx.onTouchCancel(function(){
  //手指触摸事件被打断的时候会触发
})
