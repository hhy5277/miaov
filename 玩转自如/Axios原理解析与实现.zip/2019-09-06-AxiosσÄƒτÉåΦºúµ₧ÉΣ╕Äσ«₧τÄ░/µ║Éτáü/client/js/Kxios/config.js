import ajax from './ajax'
import nodeHttp from './nodeHttp'

export default {
    baseURL: '',
    url: '',
    method: 'get',
    headers: {
        'content-type': 'application/json'
    },
    adaptor(configs) {
        if (typeof window === 'object') {
            return ajax(configs);
        } else {
            return nodeHttp(configs);
        }
    },
    transformResponse: function(data) {
        return data;
    }
    
};