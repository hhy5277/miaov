import {deepCopy, mergeConfig} from './utils';
import InterceptorManager from './InterceptorManager';
// console.log(deepCopy);

// let obj1 = {
//     baseURL: '',
//     url: '',deepCopy
//     method: 'get',
//     data: {
//         x: 1,
//         y: 2
//     },
//     arr: [1,2,3]
// };

// obj2.data = obj1.data;

// let obj2 = deepCopy(obj1);

// obj2.url = 'abc';
// obj2.data.z = 10;
// console.log(obj2);


// let obj3 = {x: 1, arr: [1,2,3], y: undefined, fn: function() {console.log('asd');}};
// let obj4 = JSON.parse(JSON.stringify(obj3));
// console.log(obj3);
// console.log(obj4);


class Kxios {

    constructor(config) {
        
        this.defaults = deepCopy(config);

        this.interceptors = {
            request: new InterceptorManager,
            response: new InterceptorManager
        }
    }

    get(url, config) {
        // console.log('...');

        // 把get传入的配置与对象默认配置进行整合
        // this.defaults.url = url;
        // this.defaults = Object.assign(this.defaults, config);
        // console.log(this.defaults);

        // let configs = Object.assign(this.defaults, config);
        let configs = mergeConfig(this.defaults, config);
        config.url = url;

        // console.log(configs)

        let promise = Promise.resolve(configs);

        this.interceptors.request.handlers.forEach(handler => {
            promise = promise.then(
                handler.resolvedHandler,
                handler.rejectedHandler
            );
        });

        promise = promise.then(this.dispatch, undefined);

        this.interceptors.response.handlers.forEach(handler => {
            promise = promise.then(
                handler.resolvedHandler,
                handler.rejectedHandler
            );
        });

        return promise;

    }

    dispatch(configs) {
        
        let adaptor = configs.adaptor(configs);

        return adaptor;

    }
    

}

export default Kxios;