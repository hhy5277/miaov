import Kxios from './Kxios';
import config from './config';

let kxios = new Kxios(config);

export default kxios;