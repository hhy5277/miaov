import http from 'http';

export default function(configs) {
    return new Promise( (resolve, reject) => {
        const postData = '';
          
        const options = {
        hostname: 'localhost',
        port: 9999,
        path: '/',
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Content-Length': Buffer.byteLength(postData)
        }
        };
        
        const req = http.request(options, (res) => {
            // console.log(`状态码: ${res.statusCode}`);
            // console.log(`响应头: ${JSON.stringify(res.headers)}`);
            res.setEncoding('utf8');
            
            let chunks = [];
            let size = 0;
            res.on('data', chunk => {
                chunks.push(chunk);
                size += chunk.length;
                // console.log(`响应主体: ${chunk}`);
            });
            res.on('end', () => {
                // console.log(chunks);
                // console.log('响应中已无数据, ${chunks}');
                resolve(chunks.join(''));
            });
        });
        
        req.on('error', (e) => {
            console.error(`请求遇到问题: ${e.message}`);
        });
        
        // 将数据写入请求主体。
        req.write(postData);
        req.end();
    } );
}