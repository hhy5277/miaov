import kxios from './Kxios';
import Kxios from './Kxios/Kxios';

console.log(kxios);

// kxios.defaults.method = 'post';

// kxios.defaults.adaptor = function(configs) {
//     return nodeHttp(configs);
// }

// kxios.defaults.transformResponse = function(data) {
//     return JSON.parse(data);
// }

kxios.interceptors.request.use(function(config) {
    console.log(1);
    return config;
}, function() {
    console.log('err', 1);
});

kxios.interceptors.request.use(function(config) {
    console.log(2);
    return config;
}, function() {
    console.log('err', 2);
});

kxios.interceptors.response.use(function(res) {
    console.log('response', res);
    return res;
}, function() {
    console.log('err', 2);
});

kxios.get('/', {
    baseURL: 'http://localhost:9999',
    headers: {
        'kaikeba': '123'
    }
})
.then( res => {
    console.log('kxios - res', res);
} );

kxios({
    baseURL: 'http://localhost:9999',
    url: '/'
});


// let api1 = new Kxios({
//     baseURL: 'http://localhost:9999'
// });

// api1.get('/data');

// let api2 = new Kxios({
//     baseURL: 'http://localhost:8888',
//     method: 'get'
// });

// // api2.get('/data');
// api2({
//     url: '/login',
//     method: 'post'
// })