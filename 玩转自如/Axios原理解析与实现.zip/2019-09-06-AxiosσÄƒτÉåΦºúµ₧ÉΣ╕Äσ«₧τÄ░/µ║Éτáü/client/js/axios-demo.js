import axios from 'axios';

axios.interceptors.request.use(function(config) {
    console.log(1);
    // config.headers.token = '';
    return config;
}, function() {
    console.log('err', 1);
});
axios.interceptors.request.use(function(config) {
    console.log(2);
    return config;
}, function() {
    console.log('err', 2);
});

axios.interceptors.response.use(function(res) {
    console.log(2);
    if (res.data.code != 0) {
        alert(res.data.message);
    }
    return res;
}, function() {
    console.log('err', 2);
});


axios.get('http://localhost:9999/')
.then( res => {
    console.log('axios - res', res);
} );

// request->qingqiu->response->then