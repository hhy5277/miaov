
require('./component/demo.js');
