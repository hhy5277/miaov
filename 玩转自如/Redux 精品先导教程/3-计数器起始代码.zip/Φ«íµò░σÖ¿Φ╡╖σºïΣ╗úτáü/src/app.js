
require('style/main.scss');

require('component/demo.js');
