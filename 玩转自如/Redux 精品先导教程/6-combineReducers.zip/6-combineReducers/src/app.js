
require('style/main.scss');

// require('component/demo.js');

// require('component/counterByDOM');
require('component/counterByRedux');
