var a: boolean = true;

var b: string = 'miaov';
// var b1: String = new String('miaov');

var c: null = null;

// 数组：一组具有相同类型特征的数据的有序集合
// var arr1: number[] = [1,2,3];
// var arr2: Array<number> = [1,2,3];

// var obj = {
//     init: 0,
//     success: 1,
//     error: 2
// }

// if (result == obj.success) {

// }

enum Color {Red, Green, Blue};
console.log(Color.Red);