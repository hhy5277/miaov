// function fn1() {

// }

// function fn1(x: number, y: number): number {
//     return x + y;
// }

// fn1(1, 2);

// var fn2 = function() {}

// var fn2: (x: number, y: number) => number = function(x: number, y: number): number {
//     return x + y;
// }

// var fn2: (x: number, y: number) => number = function(x, y) {
//     return x + y;
// }

// function fn3(x: number, y?: number): number {
//     return x + y;
// }

// fn3(1);

// function fn4(x: number, y: number): number {
//     return x * y;
// }

// 函数重载
function fn4(x: number, y: number): number;
function fn4(x: string, y: string): string;
function fn4(x: any, y: any): any {
    if (typeof x == 'number') {
        return x * y;
    } else {
        return x + y;
    }
}


fn4('a','b');
fn4(1,2);
// fn4(true, true);

