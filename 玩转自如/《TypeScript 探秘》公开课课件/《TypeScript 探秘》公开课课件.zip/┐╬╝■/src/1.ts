// console.log('Hello TypeScript');

// var str = 'Hello TypeScript';

// var str: string;

// str = 'Hello TypeScript';

var inputs = document.querySelectorAll('input');
var button = document.querySelector('button');

button.onclick = function() {

    var result: number = Number(inputs[0].value) + Number(inputs[1].value);

    console.log(result);

}