// es6
// class Person {

//     constructor(name) {
//         this.name = name;
//     }

// }

class Person {

    public name: string;
    private age: number;
    readonly gender: string;

    constructor(name: string, age: number, gender: string) {
        this.name = name;
        this.age = age;
        this.gender = gender;
    }

    public say():void {
        console.log('Hello, ' + this.name);
    }

}

class Student extends Person {

    constructor(name: string, age: number, gender: string) {
        super(name, age, gender);
    }

    getAge(): number {
        // return this.age;
        return 1;
    }

}

// let p1: Person = new Person('zmouse', 20, '男');
// p1.say();
// console.log(p1.age);

let s1: Student = new Student('leo', 40, '男');
// console.log(s1.getAge());
// s1.gender = '女';
console.log( s1.gender );


class Man {

    private _age: number;

    constructor(age: number) {
        this._age = age;
    }

    get age(): number {
        return this._age;
    }

    set age(newAge: number) {
        if (newAge < 200) {
            this._age = newAge;
        }
    }

}

// let m1: Man = new Man(10);
// m1.age = 100;
// console.log(m1.age);

class Teacher {

    age: number;

    static flag: string = '光荣的人民教师';

    constructor(age: number) {
        this.age = age;
    }

    static fn(): void {

    }

}

//let t1: Teacher = new Teacher(10);
// console.log( Teacher.flag );


function fn<T>(x: T, y: T): any {
    return x;
}

fn<string>('a','b');
fn<number>(1,1);