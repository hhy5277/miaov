function getData(): string | string[] {
    if ( Math.random() < .5 ) {
        return 'miaov';
    } else {
        return ['1','2','3'];
    }
}

var result: string | string[] = getData();

// result.length

// result.push();

if ( (<string[]>result).push ) {
    (<string[]>result).push();
} else {
    (<string>result).substring(0);
}