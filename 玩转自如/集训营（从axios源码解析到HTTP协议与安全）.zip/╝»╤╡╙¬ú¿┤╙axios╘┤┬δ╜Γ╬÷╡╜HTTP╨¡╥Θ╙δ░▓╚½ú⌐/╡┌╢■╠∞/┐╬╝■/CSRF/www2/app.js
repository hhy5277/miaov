const Koa = require('koa');
const KoaStaticCache = require('koa-static-cache');


const run = async () => {
    const app = new Koa();

    app.use( KoaStaticCache({
        prefix: '/public',
        dir: __dirname + '/public',
        dynamic: true
    }) );

    app.listen(6002, () => {
        console.log(`启动成功：http://localhost:6002`);
    });
}

run();