(async () => {
    let form;
    let {username, password} = form = document.querySelector('form');

    form.onsubmit = async function(e) {
        e.preventDefault();
        
        let {data: {code, message, data:user}} = await axios({
            method: 'post',
            url: '/login',
            data: {username:username.value,password:password.value}
        });
        
        if (code) {
            alert(message);
        } else {
            window.location = '/public/1/index.html';
        }
    }
})();