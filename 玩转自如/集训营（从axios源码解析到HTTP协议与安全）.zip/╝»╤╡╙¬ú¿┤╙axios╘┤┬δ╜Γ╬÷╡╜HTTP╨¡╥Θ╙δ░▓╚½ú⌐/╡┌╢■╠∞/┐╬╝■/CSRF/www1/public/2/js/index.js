(async () => {
    boxElement = document.querySelector('.box');

    // 验证是否登录
    {
        let {data: {code, data:user}} = await axios({
            url: '/check'
        });
        if ( code ) {
            return boxElement.innerHTML = `你还没有登录，请 <a href="/public/2/login.html">登录</a>`;
        }
    }

    // 获取articles
    {
        let buttonElement = document.createElement('button');
        let ulElement = document.createElement('ul');

        buttonElement.innerHTML = '清空数据';
        boxElement.appendChild(buttonElement);
        boxElement.appendChild(ulElement);

        let {data: {code, data: {articles}}} = await axios({
            url: '/articles'
        });
        if (!code) {
            ulElement.innerHTML = articles.map( article => `<li>${article.title}` ).join('');
        }

        // 删除
        buttonElement.onclick = async function() {

            let {data: {code}} = await axios({
                method: 'POST',
                url: `/article/clear`
            });

            if (!code) {
                ulElement.innerHTML = '';
            }

        }
    }

    

})();