const Koa = require('koa');
const KoaStaticCache = require('koa-static-cache');
const KoaSession = require('koa-session');
const Keygrip = require('keygrip');
const KoaRouter = require('koa-router');
const KoaBodyparser = require('koa-bodyparser');

let users = [
    {
        id: 1,
        username: 'leo',
        password: '123'
    },
    {
        id: 2,
        username: 'mt',
        password: '123'
    }
];
let articles = [
    {id: 1, userId: 1, title: 'aaaaa'},
    {id: 2, userId: 1, title: 'bbbbb'},
    {id: 3, userId: 1, title: 'ccccc'},
    {id: 4, userId: 1, title: 'ddddd'},
    {id: 5, userId: 2, title: '11111'},
    {id: 6, userId: 2, title: '22222'},
    {id: 7, userId: 2, title: '33333'},
    {id: 8, userId: 2, title: '44444'}
]

const run = async () => {
    const app = new Koa();

    app.keys = new Keygrip(['app', 'sha256']);
    app.use( KoaSession( {
        key: 'app-sess',
        maxAge: 86400000
    } , app) );
    
    app.use( KoaStaticCache({
        prefix: '/public',
        dir: __dirname + '/public',
        dynamic: true
    }) );

    const router = new KoaRouter();
    
    router.post('/login', KoaBodyparser(), async ctx => {
        let {username, password} = ctx.request.body;

        let user = users.find( u => u.username === username && u.password === password );

        if (!user) {
            return ctx.body = {
                code: 1,
                message: '不存在该用户或密码错误'
            }
        }

        ctx.session.id = user.id;
        ctx.session.username = user.username;

        ctx.body = {
            code: 0,
            message: '',
            data: {
                id: user.id,
                username: user.username
            }
        }
    });

    router.get('/check', async ctx => {
        if (ctx.session.id) {
            ctx.body = {
                code: 0,
                message: '',
                data: {
                    id: ctx.session.id,
                    username: ctx.session.username
                }
            }
        } else {
            ctx.body = {
                code: 1,
                message: '未登录'
            }
        }
    });

    router.get('/articles', async ctx => {

        if (!ctx.session.id) {
            return ctx.body = {
                code: 1,
                message: '未登录'
            }
        }

        ctx.body = {
            code: 0,
            message: '',
            data: {
                articles: articles.filter( a => a.userId === ctx.session.id )
            }
        }
    });

    router.get('/article/clear', async ctx => {
        if (!ctx.session.id) {
            return ctx.body = {
                code: 1,
                message: '未登录'
            }
        }

        articles = articles.filter( article => article.userId !== ctx.session.id );

        ctx.body = {
            code: 0,
            message: ''
        }
    })

    app.use(router.routes());
    
    app.listen(6001, () => {
        console.log(`启动成功：http://localhost:6001`);
    });
}

run();