const Koa = require('koa')
const sslify = require('koa-sslify').default;
const KoaRouter = require('koa-router');
const https = require('https');
const fs = require('fs');
const KoaStaticCache = require('koa-static-cache');

const app = new Koa();

app.use(sslify());

app.use( KoaStaticCache({
    prefix: '/public',
    dir: './public',
    dynamic: true
}) );

app.use(async (ctx, next) => {
    console.log('https - 请求过来了');
    ctx.set('Access-Control-Allow-Origin', '*');
    await next();
})

const router = new KoaRouter();

router.get('/', async ctx =>{

    ctx.body = '<h1>开课吧</h1>';

} );

router.get('/data1', async ctx =>{

    ctx.body = '<h1>开课吧</h1>';

} );

app.use( router.routes() );

var options = {
    key: fs.readFileSync('./private_key.pem'),  //私钥文件路径
    cert: fs.readFileSync('./ca-cert.pem')  //证书文件路径
};
https.createServer(options, app.callback()).listen(7779, () => {
    console.log('https://localhost:7779');
});