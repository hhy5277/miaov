const Koa = require('koa');
const KoaRouter = require('koa-router');
const KoaStaticCache = require('koa-static-cache');
const KoaBodyparser = require('koa-bodyparser');

const app = new Koa();

app.use( KoaStaticCache({
    prefix: '/public',
    dir: './public',
    dynamic: true
}) );

app.use(async (ctx, next) => {
    // console.log(`http - ${ctx.method.toUpperCase()} - 请求过来了`);
    console.log('headers', ctx.headers);

    // ctx.set('Access-Control-Allow-Origin', '*');

    ctx.set('Access-Control-Allow-Origin', 'http://localhost:7778');
    ctx.set('Access-Control-Allow-Credentials', true);

    if ( ctx.method.toUpperCase() === 'OPTIONS' ) {
        console.log('发送了非简单请求');
        ctx.set('Access-Control-Allow-Methods', 'OPTIONS,GET,POST,PUT');
        ctx.set('Access-Control-Allow-Headers', 'x-name');
        ctx.set('Access-Control-Allow-Headers', 'content-type');
        ctx.set('Access-Control-Max-Age', '-1');
        return ctx.body = '';
    }
    
    await next();
})

const router = new KoaRouter();


router.get('/', async ctx =>{

    ctx.body = '<h1>开课吧</h1>';

} );

router.get('/data1', async ctx =>{

    ctx.body = '<h1>开课吧</h1>';

} );

router.put('/data1', async ctx =>{

    ctx.body = '<h1>开课吧</h1>';

} );

router.post('/data1', async ctx =>{

    ctx.set('Set-Cookie', 'a=1');
    ctx.body = '<h1>开课吧 - post</h1>';

} );


app.use( router.routes() );

app.listen(7777, () => {
    console.log('http://localhost:7777');
});