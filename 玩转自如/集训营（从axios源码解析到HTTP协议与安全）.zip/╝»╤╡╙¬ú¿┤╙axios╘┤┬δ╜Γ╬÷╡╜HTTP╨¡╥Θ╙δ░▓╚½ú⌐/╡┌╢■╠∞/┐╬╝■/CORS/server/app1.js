const Koa = require('koa');
const KoaRouter = require('koa-router');
const KoaStaticCache = require('koa-static-cache');
const KoaBodyparser = require('koa-bodyparser');

const app = new Koa();

app.use( KoaStaticCache({
    prefix: '/public',
    dir: './public',
    dynamic: true
}) );

const router = new KoaRouter();


// http基础
router.get('/', async ctx =>{

    ctx.body = '<h1>开课吧</h1>';

} );

router.post('/http-post', async ctx =>{

    let bf = Buffer.alloc(0);
    ctx.req.on('data', chunk => {
        bf = Buffer.concat([bf, chunk], bf.length + chunk.length);
    });

    ctx.req.on('end', () => {
        console.log(bf.toString());
    });

    ctx.body = '<h1>开课吧</h1>';

} );

// 请求方法

router.head('/head', async ctx => {
    ctx.set('Content-Length', '123456');
    ctx.set('author', 'zMouse');
    ctx.body = 'asdasdsa';
});



// http://xxx.com/articles?page=2&order=desc

// /articles?



// 缓存
router.get('/cache', async ctx => {
    ctx.set('Cache-Control', 'public, max-age=31536000');
    ctx.body = `cache - get - ${Math.random()}`;
});
router.get('/nocache', async ctx => {
    ctx.set('Cache-Control', 'no-cache');
    ctx.body = `nocache - get - ${Math.random()}`;
});
router.put('/cache', async ctx => {
    ctx.set('Cache-Control', 'public, max-age=31536000');
    ctx.body = `cache - post - ${Math.random()}`;
});


// router.get('/401', async ctx => {
//     ctx.status = 403;
//     ctx.body = '';
// });

// router.post('/querystring', async ctx => {

//     console.log(ctx.request.query);
    
//     ctx.body = 'asdasd';
// })

router.get('/articles', async ctx => {

    // console.log(ctx.request.query);

    if ( Math.random() < 0.5 ) {
        ctx.status = 200;
        ctx.body = [1,2,3,4,5];
    } else {
        ctx.status = 404;
        ctx.body = [];

        // ctx.status = 301;
        // ctx.set('Location', 'http://kaikeba.com');
    }
    
})




app.use( router.routes() );

app.listen(7777, () => {
    console.log('http://localhost:7777');
});