const Koa = require('koa');
const KoaRouter = require('koa-router');
const KoaStaticCache = require('koa-static-cache');
const KoaBodyparser = require('koa-bodyparser');

const app = new Koa();

app.use( KoaStaticCache({
    prefix: '/public',
    dir: './public',
    dynamic: true
}) );

const router = new KoaRouter();


router.get('/', async ctx =>{

    ctx.body = '<h1>client</h1>';

} );


app.use( router.routes() );

app.listen(7778, () => {
    console.log('http://localhost:7778');
});