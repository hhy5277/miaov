module.exports = {
    get url() {
        return this.req.url;
    }
}