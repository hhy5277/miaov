# **JavaScript 高级工程师**-直播分享课



## 效果演示

​		![](E:\KKB\直播课案例\3D炫酷动效\效果演示\1.gif)

## 课前准备

- 工具
  - 编辑器 VSCode
  - 浏览器 Chorme

- 素材
  - 炫酷美图
  - 特效背景素材
  - 按钮素材
  - mTween.js文件

## 课堂主题

### 	带你玩转3D变换，掌握多样化的运动形式


## 课堂目标

1. 实现Css3立方体布局
2. 动态实现可复制布局
3. 运动框架的熟练掌握
4. 掌握幻灯片效果实现原理

## 知识点

### Css3D基本使用
    - perspective 透视 - 近大远小 1000px
    - transform-style:preserve-3d; 3D空间渲染
    - transform:rotate/translate/scale 变形

### JavaScript基础语法
    - for 循环
    - querySelector() 获取DOM元素
    - createElement() 创建DOM节点
    - forEach(el=>{el}) 循环元素
    - createDocumentFragment() 创建文档碎片
    - appendChild() 插入DOM节点
    - innerHTML 操作html
    - dataset 操作自定义属性
    - style.cssText 批量样式操作
    - clientWidth/clientHeight 元素自身宽/高
    - classList.add(); 给DOM节点添加class
    - remove() 删除DOM节点 ？
    - parseInt() 转化为整数型
    - Math.floor() 向下取整数
    - Math.random() 随机数
    - setTimeout() 单次执行定时器


​    
### Js运动框架使用方式
    - mTween.js
        - css(el,'styleName',val); 设置样式
        - css(el,'styleName'); 读取样式
        - mTween({
            el,  //运动元素
            attrs,  //修改样式值
            duration  //运动时间
            fx:'easeOutStrong'  //运动形式
            cb(){
                //回调函数
            }
          })
          
    


### 实现方法及思路
    - 定义所需属性
    - 设置全局开关
    - 封装函数
    - 链式动画实现
    - 定时器使用场景


## 扩展点

1. 多种风格形式运动
2. 布局分块比例灵活设置


## 总结

1. 培养三维立体布局思路
2. 使用js生成复杂型（重复性）布局结构
3. css3和js的无缝结合

[TOC]


## 作业 && 答疑



## 下节课预告

 







