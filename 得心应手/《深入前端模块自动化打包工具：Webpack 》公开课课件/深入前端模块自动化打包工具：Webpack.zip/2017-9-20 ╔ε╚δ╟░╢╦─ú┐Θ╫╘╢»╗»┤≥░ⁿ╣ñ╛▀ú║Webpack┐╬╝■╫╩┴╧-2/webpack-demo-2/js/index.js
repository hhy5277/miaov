import fn from './tools';

console.log('index');
fn();