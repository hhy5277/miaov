/**
 * Created by zmouse on 2017/9/20.
 * E-mail: zmouse@miaov.com
 * GitHub: zmouse@github.com
 */

import Vue from './vue';
import Hello from './hello.vue';

new Vue({
    el: '#app',
    components: {
        Hello
    }
});