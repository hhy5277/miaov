/**
 * Created by zmouse on 2017/9/20.
 * E-mail: zmouse@miaov.com
 * GitHub: zmouse@github.com
 */

import img from './1.jpg';

console.log(img);

// imgElement.src = img;