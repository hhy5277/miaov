import data from './data.json';

console.log(data);