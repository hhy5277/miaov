/**
 * Created by zmouse on 2017/9/20.
 * E-mail: zmouse@miaov.com
 * GitHub: zmouse@github.com
 */

import content from './raw.txt';

console.log(content);
