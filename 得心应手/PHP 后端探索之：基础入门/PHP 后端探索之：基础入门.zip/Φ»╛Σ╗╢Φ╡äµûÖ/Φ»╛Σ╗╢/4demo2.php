<?php
/**
 * Created by miaov.com - PHP之旅.
 * User: miaov
 * Details: 
 */
/*echo 'string';

echo '<br>';

echo 1;

echo '<br>';

echo 1.5;
*/

//echo true;

//echo '<br>';

//echo false;

//var_dump(1);

/*$newsTitle = 'miaov';
$newsTitle2 = ' news';

$newsTitle3 = '妙味课堂';

var_dump($newsTitle3) ;

echo '<br>';

//var_dump(trim($newsTitle2)) ;

echo '<br>';


echo mb_strlen($newsTitle3);*/

/*$connection = mysql_connect('localhost','root','');
var_dump($connection);*/

$null = 1;
unset($null);
var_dump($null);

































