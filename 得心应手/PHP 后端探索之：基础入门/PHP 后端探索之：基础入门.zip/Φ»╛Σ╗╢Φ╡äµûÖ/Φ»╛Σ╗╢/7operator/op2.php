<?php
/**
 * Created by miaov.com - PHP之旅.
 * User: miaov
 * Details: 
 */

$a = 5;

echo $a ;

echo '<br>';

$b = $a--;

echo $a ;

echo '<br>';

echo $b;