<?php
/**
 * Created by miaov.com - PHP之旅.
 * User: miaov
 * Details: 
 */
// == ===
// != <>  !==
// > < >= <=
$a = 1;
$b = '1';

var_dump($a !== $b);
