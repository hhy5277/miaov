<?php
/**
 * Created by miaov.com - PHP之旅.
 * User: miaov
 * Details: 
 */
// && and
$true = true;
$false = false;

//var_dump($true&&$false);

//|| or

//var_dump($false||$false);


//!
//var_dump(!$false);

//xor
var_dump($false xor $false );

