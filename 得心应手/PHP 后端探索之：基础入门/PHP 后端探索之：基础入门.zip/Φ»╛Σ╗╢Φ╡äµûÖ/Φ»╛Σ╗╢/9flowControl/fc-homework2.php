<?php
/**
 * Created by miaov.com - PHP之旅.
 * User: miaov
 * Details: 
 */
$arr = [];
if(is_array($arr)){
//    foreach
}