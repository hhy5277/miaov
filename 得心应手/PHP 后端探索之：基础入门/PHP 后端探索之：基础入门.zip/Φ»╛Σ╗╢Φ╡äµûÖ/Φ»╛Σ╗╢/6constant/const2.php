<?php
/**
 * Created by miaov.com - PHP之旅.
 * User: miaov
 * Details: 
 */
//defined()
define('USERNAME','root');

//var_dump(defined("USERNAME1"));

//isset()

$user = null;

var_dump(isset($user));