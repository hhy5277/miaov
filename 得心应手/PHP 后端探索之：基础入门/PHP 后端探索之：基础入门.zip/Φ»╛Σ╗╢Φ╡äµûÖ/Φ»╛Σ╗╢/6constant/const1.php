<?php
/**
 * Created by miaov.com - PHP之旅.
 * User: miaov
 * Details: 
 */
//define(name,value,[false/true])

define("DATABASE",'news');

//echo 'database is '.DATABASE;

define("VIP_PRICE",199);

//echo VIP_PRICE;

var_dump(PHP_OS);