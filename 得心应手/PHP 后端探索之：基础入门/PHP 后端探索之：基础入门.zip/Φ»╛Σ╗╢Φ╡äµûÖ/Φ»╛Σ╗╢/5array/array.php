<?php
/**
 * Created by miaov.com - PHP之旅.
 * User: miaov
 * Details: 
 */
/*
 * 定义数组
 * array()
 * []
 */

$newsList = array();

$newsList2 = [];

var_dump($newsList);
var_dump($newsList2);