<?php
/**
 * Created by miaov.com - PHP之旅.
 * User: miaov
 * Details:
 */
echo 1+true;

echo '<br>';

echo 1+false;

echo '<br>';

echo 1+null;
