<?php
/**
 * Created by miaov.com - PHP之旅.
 * User: miaov
 * Details: 
 */
//var_dump(true&&true);

var_dump(''&&true);

var_dump('0'&&true);

var_dump(0&&true);

var_dump(0.0&&true);

var_dump(null&&true);

var_dump([]&&true);
