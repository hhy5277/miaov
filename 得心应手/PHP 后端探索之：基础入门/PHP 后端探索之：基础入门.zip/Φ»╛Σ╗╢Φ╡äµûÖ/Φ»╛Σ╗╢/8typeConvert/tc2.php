<?php
/**
 * Created by miaov.com - PHP之旅.
 * User: miaov
 * Details: 
 */

echo 1+1.0;

var_dump(1+1.0);