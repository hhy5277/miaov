export default {
  domain: 'https://db.miaov.com/doubanapi/v0/movie'
}