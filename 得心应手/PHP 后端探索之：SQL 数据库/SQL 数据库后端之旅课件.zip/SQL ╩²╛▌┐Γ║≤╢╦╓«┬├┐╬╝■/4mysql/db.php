<?php
/**
 * Created by miaov.com - PHP之旅.
 * User: miaov
 * Details: 
 */
$db = array(
    'server' => '127.0.0.1',
    'user' => 'root',
    'pwd' => '',
    'database' => 'news',
);