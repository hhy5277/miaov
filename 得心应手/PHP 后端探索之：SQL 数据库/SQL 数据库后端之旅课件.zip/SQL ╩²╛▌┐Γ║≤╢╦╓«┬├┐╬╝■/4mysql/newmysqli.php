<head lang="en">
    <meta charset="UTF-8">
    <title>newmysqli</title>
</head>

<?php
include_once('db.php');

// 创建连接
$con = new mysqli($db['server'],$db['user'],$db['pwd'],$db['database']);

// 检测连接
if ($con->connect_error) {
    die("连接失败: " . $con->connect_error);
}

echo '====分割线，查询用户数据====</br></br>';

$sql = "select * from user ";

$result = $con->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        print_r($row);
        echo "<br />";
    }
} else {
    echo "没有数据";
}



echo '</br>====分割线，插入用户数据====</br>';

$username = 'phper3';
$password = '123456';

$selectUsernameSql =  "select * from user where username = '".$username."'";

$result = $con->query($selectUsernameSql);

if ($result->num_rows > 0) {
    echo "</br>该用户名 $username 已经存在</br>";
} else {
    $insertSql = "insert into user (username,password) values ('".$username."','".$password."')";

    if ($con->query($insertSql)) {
        echo "</br>插入成功</br>";
    }
}


echo '</br>====分割线，修改用户数据====</br>';

$username = 'phper2';
$newPwd = $username;

$selectUsernameSql =  "select * from user where username = '".$username."'";

$result = $con->query($selectUsernameSql);

if ($result->num_rows > 0) {
    $updateSql = "update user set password = '".$newPwd."' where username = '".$username."'";

    if ($con->query($updateSql)) {
        echo "</br>修改成功</br>";
    }

} else {
    echo "</br>该用户名 $username 不存在</br>";
}


echo '</br>====分割线，删除用户数据====</br>';

$username = 'phper24';

$selectUsernameSql =  "select * from user where username = '".$username."'";

$result =  $con->query($selectUsernameSql);

if ($result->num_rows > 0) {
    $deleteSql = "delete from user where username = '" . $username . "'";

    if ($con->query($deleteSql)) {
        echo "</br>删除成功</br>";
    }

} else {
    echo "</br>该用户名 $username 不存在</br>";
}

echo '</br>====分割线，查询用户数据====</br></br>';

$sql = "select * from user ";

$result = $con->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        print_r($row);
        echo "<br />";
    }
} else {
    echo "没有数据";
}

//关闭连接
$con->close();