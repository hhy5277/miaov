<head lang="en">
    <meta charset="UTF-8">
    <title>PDO</title>
</head>

<?php
include_once('db.php');

$con = new PDO("mysql:host=127.0.0.1;dbname=news",$db['user'],$db['pwd']);

echo '====分割线，查询用户数据====</br></br>';

$sql = "select * from user ";

//PDO::prepare —准备要执行的SQL语句并返回一个 PDOStatement 对象
$command = $con->prepare($sql);

//PDOStatement::execute — 执行一条预处理语句
$command->execute();

//PDOStatement::fetchAll — 返回一个包含结果集中所有行的数组
$userArr = $command->fetchAll();
if(count($userArr) > 0){
    foreach($userArr as $user){
        print_r($user);
        echo "<br />";
    }
}else{
    echo "没有数据";
}


echo '</br>====分割线，插入用户数据====</br>';

$username = 'phper4';
$password = '123456';

//使用命名（:name）参数来准备SQL语句
$selectUsernameSql =  "select * from user where username = :username";
$command = $con->prepare($selectUsernameSql);

//通过数组值向预处理语句传递真实的参数
$command->execute(array(':username'=>$username));

$userArr = $command->fetchAll();
if(count($userArr) > 0){
    echo "</br>该用户名 $username 已经存在</br>";
} else {
    $insertSql = "insert into user (username,password) values (:username, :password)";

    $command = $con->prepare($insertSql);
    $result = $command->execute(array(':username'=>$username,':password'=>$password));

    echo "</br>插入成功</br>";
}

echo '</br>====分割线，修改用户数据====</br>';

$username = 'phper2';
$newPwd = $username;

$selectUsernameSql =  "select * from user where username = :username";

$command = $con->prepare($selectUsernameSql);
$command->execute(array(':username'=>$username));

$userArr = $command->fetchAll();
if(count($userArr) > 0){
    $updateSql = "update user set password = :password where username = :username";

    $command = $con->prepare($updateSql);
    $result = $command->execute(array(':username'=>$username,':password'=>$newPwd));
    echo "</br>修改成功</br>";

} else {
    echo "</br>该用户名 $username 不存在</br>";
}


echo '</br>====分割线，删除用户数据====</br>';

$username = 'phper2';

$selectUsernameSql =  "select * from user where username = :username";

$command = $con->prepare($selectUsernameSql);
$command->execute(array(':username'=>$username));

$userArr = $command->fetchAll();
if(count($userArr) > 0){
    $deleteSql = "delete from user where username = :username";

    $command = $con->prepare($deleteSql);
    $result = $command->execute(array(':username'=>$username));

    echo "</br>删除成功</br>";

} else {
    echo "</br>该用户名 $username 不存在</br>";
}



echo '</br>====分割线，查询用户数据====</br></br>';

$sql = "select * from user ";

$command = $con->prepare($sql);
$command->execute();

$userArr = $command->fetchAll();
if(count($userArr) > 0){
    foreach($userArr as $user){
        print_r($user);
        echo "<br />";
    }
}else{
    echo "没有数据";
}

//关闭连接
$con = null;


