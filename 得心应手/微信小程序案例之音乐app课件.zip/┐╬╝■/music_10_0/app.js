//app.js
App({
  globalData: {
    song: null
  }
})