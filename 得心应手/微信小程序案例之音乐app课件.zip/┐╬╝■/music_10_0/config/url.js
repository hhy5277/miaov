var baseurl = "http://localhost:3000"

export default {
  list: baseurl + "/top/list",
  song: baseurl + "/song/detail",
  lyric: baseurl + "/lyric"
}