// pages/play/play.js
import url from "../../config/url.js";
var app = getApp();
Page({
  data: {
    song: {},
    duration: 0,
    current: 0,
    isDown: false,
    lrc: {
      "0": "正在获取歌词"
    },
    currentLrc: ""
  },
  onLoad: function (options) {
    console.log( options.id );
    let {id} = options;
    // id = 1296583188;

    wx.request({
      url: `${url.lyric}?id=${id}`,
      success: (res)=>{
        console.log("获取歌词: ",res);
        let { lyric } = res.data.lrc;
        console.log( lyric );
        let r = /\[(.*?)](.*)/g;
        var obj = {};
        lyric.replace( r,($0,$1,$2)=>{
          // console.log( $1,$2 ) 
          obj[$1.substring(0,5)] = $2
        } );
        this.setData( {
          lrc: obj
        } )
      }
    })

    wx.request({
      url: `${url.song}?ids=${id}`,
      success: (res)=>{
        console.log(res )
        this.setData({
          song: res.data.songs[0]
        });
        wx: wx.setNavigationBarTitle({
          title: res.data.songs[0].name
        })
      }
    });
    let { song } = app.globalData; 
    if ( !song ){
      song = app.globalData.song = wx.createInnerAudioContext();
    }
    song.src = `http://music.163.com/song/media/outer/url?id=${id}.mp3`;
    song.pause(); // 先停止 再调用 播放 , 否则有可能更新(onTimeUpdate)不会触发
    song.play();
    song.onPlay( res=>{
      console.log("开始播放");
    } )
    song.onTimeUpdate( res=>{
      // console.log( song );
      if (this.data.duration !== song.duration ){
        this.setData({
          duration: song.duration
        })
      };
      if( !this.data.isDown ){
        this.setData({
          current: song.currentTime
        })
      };
      let { currentTime: c } = song;
      let min = Math.floor( c / 60 );
      let sec = Math.floor( c % 60 );
      var attr = (min < 10 ? "0" + min : "" + min) + ":" + (sec < 10 ? "0" + sec : "" + sec);

      console.log(attr)
      if (attr in this.data.lrc && "el-" +attr !== this.data.currentLrc ){
        console.log("滚动歌词啦!")
        this.setData({
          currentLrc: "el-"+attr
        })
      }
    } )
  },
  changing(){
    this.setData({ 
      isDown: true
    })  
  },
  change(e){
    console.log(e.detail)
    this.setData({
      isDown: false
    })
    app.globalData.song.seek(e.detail.value)
  },
  tap(){
    let {song} = app.globalData;
    song.paused ? song.play() : song.pause();
  }
})