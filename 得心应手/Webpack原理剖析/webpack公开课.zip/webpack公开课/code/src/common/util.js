module.exports = (age)=>{
  console.log('你今年'+age+'岁了')
}