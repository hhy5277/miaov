const sayHi = require('./a.js')

sayHi('开课吧')