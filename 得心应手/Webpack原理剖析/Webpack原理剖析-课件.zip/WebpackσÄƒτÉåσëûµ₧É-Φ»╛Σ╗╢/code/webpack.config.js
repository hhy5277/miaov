module.exports = {
  mode:'development',
  // 项目入口
  entry:"./src/index.js",
  // 项目出口
  output:{
      filename:'pack.js'
  }
}