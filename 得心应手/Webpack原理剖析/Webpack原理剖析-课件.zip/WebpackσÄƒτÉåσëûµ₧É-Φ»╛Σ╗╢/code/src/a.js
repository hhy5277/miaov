const sayAge = require('./common/util.js')
module.exports = (name)=>{
  console.log('hello world'+ name)
  sayAge(18)
}
