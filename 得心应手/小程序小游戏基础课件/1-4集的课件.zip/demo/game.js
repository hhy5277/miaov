var canvas = wx.createCanvas()

//默认的画布宽高就是屏幕宽高
// canvas.width = 200
// canvas.height = 250
// console.log(canvas.width)
// console.log(canvas.height)

//设置2d渲染
var ctx = canvas.getContext('2d')

// ctx.fillStyle = 'red'
// ctx.fillRect(0,0,100,100)


//创建图片对象
var img = wx.createImage()
//设置图片地址
img.src = './source/bg.jpg'


//创建多个canvas对象
var canvasTwo = wx.createCanvas()
var ctxTwo = canvasTwo.getContext('2d')

ctxTwo.fillStyle = 'blue'
ctxTwo.fillRect(0,0,100,100)


//上屏和离屏
/*
  上屏：第一次创建canvas对象时候，生成的画布，在该画布上面绘制的元素，都会显示在屏幕上

  离屏：在第一次创建完成之后的canvas对象创建，生成画布，我们都称为离屏，在离屏上面绘制的元素，不会显示到我们的屏幕上
*/

//等待图片加载完成之后，然后进行绘制
img.onload = function () {
  ctx.drawImage(img, 0, 0, canvas.width, canvas.height)

  //文字元素的绘制
  ctx.fillStyle = 'red'
  ctx.font = '30px Arial'
  ctx.fillText('Hello,world', 0, 100)
  ctx.drawImage(canvasTwo, 0, 0)
}
//创建音频对象
var bgm = wx.createInnerAudioContext()
// mp3 aac wav
bgm.src = './source/bgm.mp3'
//调用音频播放
bgm.play()

//循环播放
bgm.loop = true

//自动播放
bgm.autoplay = true

//ios系统下，就算是静音，也同样播放声音
bgm.obeyMuteSwitch = false

wx.onShow(function(){
  bgm.play()
})

wx.onAudioInterruptionEnd(function(){
  bgm.play()
})

wx.onAudioInterruptionBegin(function(){
  //中断的开始，在游戏强依赖音乐的时候，我们不止需要中断音乐，还需要在这里中断游戏
})




