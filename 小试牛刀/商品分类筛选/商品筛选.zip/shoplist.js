var shopsList = [
	{
		imgUrl:'',
		size: '4.0-4.5英寸',
		system: 'ios',
		www:'联通3G',
		name:'苹果',
		volume:100000,
		price: 5000
	},
	{
		imgUrl:'',
		size: '4.0-4.5英寸',
		system: 'ios',
		www:'双卡单4G',
		name:'苹果',
		volume:100,
		price: 50000
	},
	{
		imgUrl:'',
		size: '4.6-4.9英寸',
		system: 'ios',
		www:'双卡单4G',
		name:'苹果',
		volume:30,
		price: 50080
	},
	{
		imgUrl:'',
		size: '4.6-4.9英寸',
		system: 'android',
		www:'联通3G',
		name:'小米',
		volume:1020,
		price: 50400
	},
	{
		imgUrl:'',
		size: '4.0-4.5英寸',
		system: 'android',
		www:'双卡单4G',
		name:'小米',
		volume:1040,
		price: 54000
	},
	{
		imgUrl:'',
		size: '4.6-4.9英寸',
		system: 'android',
		www:'双卡单4G',
		name:'小米',
		volume:1004,
		price: 50040
	}
]