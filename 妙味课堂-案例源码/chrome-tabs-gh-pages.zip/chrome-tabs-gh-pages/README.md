### Chrome Tabs in Chrome

Exactly what you think this is. Go wild.

Drag-and-drop support provided by [Draggabilly](https://github.com/desandro/draggabilly) by @desandro.

### [Demo](http://adamschwartz.co/chrome-tabs/)

<img width=868 src=http://adamschwartz.co/chrome-tabs/chrome-tabs.gif>

<br><br><br><br><br><br><br><br>

<hr>

[Older versions](older-versions.md)
