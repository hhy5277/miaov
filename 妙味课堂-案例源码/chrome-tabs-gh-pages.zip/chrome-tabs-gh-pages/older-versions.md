### Older versions

This repo attempts to match the latest Google Chrome design at the time. Here is a list of prior stable versions:

- Pre-Chrome 52 “Material Design” ([0c8c8f1880](https://github.com/adamschwartz/chrome-tabs/tree/0c8c8f18802cf67091151bb812d9693bee55b085))

  ![](https://github.com/adamschwartz/chrome-tabs/raw/0c8c8f18802cf67091151bb812d9693bee55b085/chrome-tabs.gif)

- Pre rMBP ([c1b0b0eb8c](https://github.com/adamschwartz/chrome-tabs/tree/c1b0b0eb8c9d2452ee23520802abd7edf71200a8))

  ![](https://github.com/adamschwartz/chrome-tabs/raw/c1b0b0eb8c9d2452ee23520802abd7edf71200a8/chrome-tabs.gif)
