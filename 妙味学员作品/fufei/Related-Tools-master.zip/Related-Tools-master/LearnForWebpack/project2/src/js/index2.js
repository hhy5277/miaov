(() => {
    alert('test for package')
})()