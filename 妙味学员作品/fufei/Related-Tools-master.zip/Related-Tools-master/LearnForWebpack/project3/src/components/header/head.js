import template1 from './header.html';

let sayHi = () => {
    return {
        name: 'tlp',
        con: template1
    }
}

export default sayHi;