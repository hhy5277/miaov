import 'mint-ui/src/style/empty.css';
export { default } from '../swipe/src/swipe-item.vue';
