export { default } from './src/index-list.vue';
